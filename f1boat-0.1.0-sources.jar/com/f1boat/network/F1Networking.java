package com.f1boat.network;

import com.f1boat.server.F1Server;
import com.f1boat.util.F1Constants;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;

/**
 * Networking do mod. Código COMUM: não importe classes de cliente aqui
 * (o envio pelo cliente fica em com.f1boat.client).
 */
public final class F1Networking {

    /**
     * Pedido CLIENTE -> SERVIDOR: "quero ativar o ERS".
     * Propositalmente vazio: o cliente não envia duração, cooldown, velocidade nem bônus.
     */
    public record ActivateErsPayload() implements CustomPacketPayload {

        public static final ActivateErsPayload INSTANCE = new ActivateErsPayload();

        public static final CustomPacketPayload.Type<ActivateErsPayload> TYPE =
                new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(F1Constants.MOD_ID, "activate_ers"));

        public static final StreamCodec<RegistryFriendlyByteBuf, ActivateErsPayload> CODEC =
                StreamCodec.unit(INSTANCE);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /**
     * Estado SERVIDOR -> CLIENTE: o que o servidor decidiu. O cliente só lê e aplica.
     * bonusBps já é o bônus escolhido (ERS OU vácuo OU 0), nunca a soma dos dois.
     */
    public record StatePayload(int ersActiveTicks, int ersCooldownTicks, boolean inSlipstream, double bonusBps)
            implements CustomPacketPayload {

        public static final CustomPacketPayload.Type<StatePayload> TYPE =
                new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(F1Constants.MOD_ID, "state"));

        public static final StreamCodec<RegistryFriendlyByteBuf, StatePayload> CODEC = StreamCodec.composite(
                ByteBufCodecs.VAR_INT, StatePayload::ersActiveTicks,
                ByteBufCodecs.VAR_INT, StatePayload::ersCooldownTicks,
                ByteBufCodecs.BOOL, StatePayload::inSlipstream,
                ByteBufCodecs.DOUBLE, StatePayload::bonusBps,
                StatePayload::new
        );

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    private F1Networking() {
    }

    /**
     * Registra os payloads (nos dois lados) e o receptor do servidor.
     * Chamado por F1BoatMod.onInitialize.
     */
    public static void register() {
        PayloadTypeRegistry.serverboundPlay().register(ActivateErsPayload.TYPE, ActivateErsPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(StatePayload.TYPE, StatePayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(
                ActivateErsPayload.TYPE,
                (payload, context) -> onActivateErsRequest(context.player())
        );
    }

    /** Envia o estado ao jogador (ignora quem não tem o mod no cliente). */
    public static void sendState(ServerPlayer player, StatePayload payload) {
        if (ServerPlayNetworking.canSend(player, StatePayload.TYPE)) {
            ServerPlayNetworking.send(player, payload);
        }
    }

    /**
     * Roda na thread do servidor. O servidor decide: o cliente só pediu.
     * O ErsManager valida tudo (barco, vácuo, ERS ativo, recarga); o resultado aparece no HUD.
     */
    private static void onActivateErsRequest(ServerPlayer player) {
        F1Server.ERS.activate(player);
    }
}