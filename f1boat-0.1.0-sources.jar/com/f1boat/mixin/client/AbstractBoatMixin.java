package com.f1boat.mixin.client;

import com.f1boat.client.F1ClientState;
import com.f1boat.server.BoatSpeedManager;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.vehicle.boat.AbstractBoat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * MIXIN MÍNIMO (somente cliente).
 *
 * Por quê: o barco dirigido por um jogador é simulado pelo CLIENTE do motorista
 * (o servidor só recebe a posição). Logo, o bônus de velocidade precisa entrar na física
 * do cliente. O valor do bônus vem do SERVIDOR (F1ClientState), nunca é decidido aqui.
 *
 * Como: injeta no fim do tick() do barco (método público, não depende de campos privados).
 * Enquanto o motorista local acelera (tecla "frente") e a velocidade horizontal está abaixo de
 * (velocidade normal + bônus), soma um empurrão para frente. A velocidade nunca passa desse alvo,
 * então não há acúmulo. Quando o bônus acaba, o atrito normal traz a velocidade de volta.
 *
 * A velocidade normal e o atrito vêm de BoatSpeedManager (mesma conta do servidor).
 */
@Mixin(AbstractBoat.class)
public abstract class AbstractBoatMixin {

    @Inject(method = "tick", at = @At("TAIL"))
    private void f1boat$applyBonus(CallbackInfo ci) {
        AbstractBoat boat = (AbstractBoat) (Object) this;

        // Nunca roda no servidor (singleplayer tem os dois lados na mesma JVM).
        if (!boat.level().isClientSide()) {
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || boat.getControllingPassenger() != minecraft.player) {
            return;
        }

        // Só empurra enquanto o jogador acelera para frente.
        if (!minecraft.options.keyUp.isDown()) {
            return;
        }

        double bonusBps = F1ClientState.getBonusBps();
        if (bonusBps <= 0.0) {
            return;
        }

        double bonusPerTick = bonusBps / 20.0;
        double friction = BoatSpeedManager.getFriction(boat);
        double targetPerTick = BoatSpeedManager.getNormalMaxSpeedBps(boat) / 20.0 + bonusPerTick;

        double currentPerTick = boat.getDeltaMovement().horizontalDistance();
        if (currentPerTick >= targetPerTick) {
            return;
        }

        // Empurrão que, no equilíbrio com o atrito, soma exatamente o bônus; limitado ao que falta
        // para o alvo, para nunca ultrapassá-lo.
        double extra = Math.min((1.0 - friction) * bonusPerTick / friction, targetPerTick - currentPerTick);

        // Mesma direção "para frente" usada pela física do barco: (-sen(yaw), 0, cos(yaw)).
        double yaw = Math.toRadians(boat.getYRot());
        boat.setDeltaMovement(boat.getDeltaMovement().add(
                -Math.sin(yaw) * extra,
                0.0,
                Math.cos(yaw) * extra
        ));
    }
}