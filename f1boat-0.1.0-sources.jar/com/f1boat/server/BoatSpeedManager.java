package com.f1boat.server;

import com.f1boat.util.F1Constants;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.vehicle.boat.AbstractBoat;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Medição, referência e escolha do bônus de velocidade do barco.
 *
 * Por que MEDIR em vez de ler a velocidade do barco: o barco dirigido por um jogador é
 * simulado pelo CLIENTE do motorista; no servidor a velocidade interna do barco fica zerada.
 * A velocidade real é, portanto, a diferença de posição entre ticks.
 *
 * A APLICAÇÃO do bônus acontece no cliente (AbstractBoatMixin), com o valor escolhido aqui.
 * As contas de referência (atrito e velocidade máxima normal) são static e compartilhadas
 * com o Mixin, para existir uma única implementação.
 */
public final class BoatSpeedManager {

    /** Aceleração para frente do vanilla: 0.04 blocos/tick por tick. */
    private static final double VANILLA_FORWARD_ACCELERATION = 0.04;

    /** Atrito do vanilla na água e no ar (0.9). */
    private static final double VANILLA_WATER_AIR_FRICTION = 0.9;

    /** Suavização da velocidade medida (0..1): maior = reage mais rápido, oscila mais. */
    private static final double SMOOTHING = 0.3;

    private static final class SpeedState {
        final UUID boatId;
        Vec3 lastPos;
        double smoothedBlocksPerTick;

        SpeedState(UUID boatId, Vec3 lastPos) {
            this.boatId = boatId;
            this.lastPos = lastPos;
        }
    }

    private final Map<UUID, SpeedState> states = new HashMap<>();

    /** Atualiza a medição. Chamado uma vez por tick, para cada jogador online. */
    public void tick(ServerPlayer player) {
        AbstractBoat boat = F1Server.getDrivenBoat(player);
        if (boat == null) {
            states.remove(player.getUUID());
            return;
        }

        Vec3 pos = boat.position();
        SpeedState state = states.get(player.getUUID());

        // Primeiro tick num barco (ou trocou de barco): ainda não há diferença para medir.
        if (state == null || !state.boatId.equals(boat.getUUID())) {
            states.put(player.getUUID(), new SpeedState(boat.getUUID(), pos));
            return;
        }

        double instant = pos.subtract(state.lastPos).horizontalDistance();
        state.smoothedBlocksPerTick += (instant - state.smoothedBlocksPerTick) * SMOOTHING;
        state.lastPos = pos;
    }

    /** Velocidade horizontal medida, em blocos por segundo (0 se não está num barco). */
    public double getMeasuredSpeedBps(ServerPlayer player) {
        SpeedState state = states.get(player.getUUID());
        return state == null ? 0.0 : state.smoothedBlocksPerTick * F1Constants.TICKS_PER_SECOND;
    }

    /**
     * Atrito do barco na superfície atual (0.9 na água/ar; atrito do bloco em terra).
     * Compartilhado com o Mixin do cliente.
     */
    public static double getFriction(AbstractBoat boat) {
        double friction = VANILLA_WATER_AIR_FRICTION;

        if (!boat.isInWater()) {
            BlockPos below = BlockPos.containing(boat.getX(), boat.getY() - 0.5, boat.getZ());
            BlockState state = boat.level().getBlockState(below);
            if (!state.isAir()) {
                friction = state.getBlock().getFriction();
            }
        }

        return Math.min(friction, 0.999); // evita divisão por zero
    }

    /**
     * Velocidade máxima NORMAL (sem bônus) do barco na superfície atual, em blocos/s.
     * Física vanilla: a cada tick v = v * atrito + 0.04, logo v_max = 0.04 / (1 - atrito) blocos/tick.
     */
    public static double getNormalMaxSpeedBps(AbstractBoat boat) {
        return VANILLA_FORWARD_ACCELERATION / (1.0 - getFriction(boat)) * F1Constants.TICKS_PER_SECOND;
    }

    /** O barco do jogador está na velocidade máxima normal (com pequena tolerância)? */
    public boolean isAtMaximumNormalSpeed(ServerPlayer player, AbstractBoat boat) {
        return getMeasuredSpeedBps(player) >= getNormalMaxSpeedBps(boat) - F1Constants.MAX_SPEED_TOLERANCE_BPS;
    }

    /**
     * REGRA CENTRAL: o bônus que vale AGORA, em blocos/s. É UM só valor:
     *   ERS ativo  -> +2.5
     *   vácuo      -> +2.0
     *   nenhum     -> 0
     * Nunca soma os dois. Se os dois fossem verdadeiros, o ERS vence (o máximo é +2.5).
     */
    public double getActiveBonusBps(ServerPlayer player) {
        if (F1Server.getDrivenBoat(player) == null) {
            return 0.0;
        }
        if (F1Server.ERS.isActive(player)) {
            return F1Constants.ERS_BONUS_BPS;
        }
        if (F1Server.SLIPSTREAM.isInSlipstream(player)) {
            return F1Constants.SLIPSTREAM_BONUS_BPS;
        }
        return 0.0;
    }

    /** Velocidade máxima esperada agora: normal + bônus (um só). */
    public double getTargetMaxSpeedBps(ServerPlayer player, AbstractBoat boat) {
        return getNormalMaxSpeedBps(boat) + getActiveBonusBps(player);
    }

    public void clear() {
        states.clear();
    }
}