package com.f1boat.server;

import com.f1boat.util.F1Constants;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.vehicle.boat.AbstractBoat;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Detecção do vácuo (slipstream). Só DETECTA: o bônus de velocidade é da Fase 6.
 *
 * O resultado é recalculado todo tick e guardado. Se qualquer condição deixa de valer,
 * o jogador sai do mapa (vácuo removido) já no tick seguinte.
 */
public final class SlipstreamManager {

    /** jogador -> barco que ele está seguindo. Presença no mapa = em vácuo. */
    private final Map<UUID, UUID> targets = new HashMap<>();

    public boolean isInSlipstream(ServerPlayer player) {
        return targets.containsKey(player.getUUID());
    }

    /** Chamado uma vez por tick, depois de BoatSpeedManager.tick. */
    public void tick(ServerPlayer player) {
        AbstractBoat target = computeTarget(player);
        if (target == null) {
            targets.remove(player.getUUID());
        } else {
            targets.put(player.getUUID(), target.getUUID());
        }
    }

    /** Condições 1, 6 e 8: no barco, na velocidade máxima normal e sem ERS. Depois, procura o alvo. */
    private AbstractBoat computeTarget(ServerPlayer player) {
        if (F1Server.ERS.isActive(player)) {
            return null;
        }

        AbstractBoat boat = F1Server.getDrivenBoat(player);
        if (boat == null) {
            return null;
        }

        if (!F1Server.BOAT_SPEED.isAtMaximumNormalSpeed(player, boat)) {
            return null;
        }

        return findSlipstreamTarget(boat);
    }

    /** Barco válido mais próximo dentro do alcance, ou null. */
    public AbstractBoat findSlipstreamTarget(AbstractBoat source) {
        AABB area = source.getBoundingBox().inflate(F1Constants.SLIPSTREAM_RANGE);
        List<AbstractBoat> candidates = source.level().getEntitiesOfClass(
                AbstractBoat.class, area, other -> other != source
        );

        AbstractBoat best = null;
        double bestDistanceSqr = Double.MAX_VALUE;

        for (AbstractBoat candidate : candidates) {
            if (!isValidSlipstreamTarget(source, candidate)) {
                continue;
            }
            double distanceSqr = candidate.position().subtract(source.position()).lengthSqr();
            if (distanceSqr < bestDistanceSqr) {
                bestDistanceSqr = distanceSqr;
                best = candidate;
            }
        }
        return best;
    }

    /** Todas as condições geométricas entre dois barcos. */
    public boolean isValidSlipstreamTarget(AbstractBoat source, AbstractBoat target) {
        if (target.isRemoved()) {
            return false;
        }

        Vec3 toTarget = target.position().subtract(source.position());
        if (toTarget.length() > F1Constants.SLIPSTREAM_RANGE) {
            return false;
        }

        // A geometria é toda no plano horizontal.
        Vec3 toTargetFlat = toTarget.multiply(1.0, 0.0, 1.0);
        Vec3 forward = forwardOf(source);

        return isAhead(forward, toTargetFlat)
                && isAligned(forward, toTargetFlat)
                && isMovingSameDirection(source, target);
    }

    /** O alvo está à frente (e não atrás ou ao lado)? */
    private boolean isAhead(Vec3 forward, Vec3 toTargetFlat) {
        return forward.dot(toTargetFlat) >= F1Constants.SLIPSTREAM_MIN_FORWARD_DISTANCE;
    }

    /** O alvo está no eixo do barco (pouco deslocamento lateral)? */
    private boolean isAligned(Vec3 forward, Vec3 toTargetFlat) {
        // |forward x toTarget| = distância lateral, pois forward tem comprimento 1.
        return forward.cross(toTargetFlat).length() <= F1Constants.SLIPSTREAM_MAX_LATERAL_OFFSET;
    }

    /** Os dois barcos apontam aproximadamente para o mesmo lado? */
    private boolean isMovingSameDirection(AbstractBoat source, AbstractBoat target) {
        return forwardOf(source).dot(forwardOf(target)) >= F1Constants.SLIPSTREAM_MIN_DIRECTION_DOT;
    }

    /** Vetor unitário "para frente" do barco, igual ao do controlBoat do vanilla. */
    private static Vec3 forwardOf(AbstractBoat boat) {
        double yaw = Math.toRadians(boat.getYRot());
        return new Vec3(-Math.sin(yaw), 0.0, Math.cos(yaw));
    }

    public void clear() {
        targets.clear();
    }
}