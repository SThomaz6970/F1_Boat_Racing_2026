package com.f1boat.server;

import com.f1boat.util.F1Constants;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;

/**
 * Estado do ERS de cada jogador. Autoritativo no servidor.
 *
 * Fluxo: disponível -> ativo (ERS_DURATION_TICKS) -> recarga (ERS_COOLDOWN_TICKS) -> disponível.
 * A recarga começa no mesmo tick em que o ERS termina. Tudo é contado em ticks do servidor.
 * Os contadores só andam enquanto o jogador está online e continuam andando mesmo que ele
 * saia do barco (sair do barco não zera a recarga).
 */
public final class ErsManager {

    /** Resultado de um pedido de ativação. */
    public enum ActivationResult {
        OK,
        NOT_DRIVING_BOAT,
        ALREADY_ACTIVE,
        ON_COOLDOWN,
        IN_SLIPSTREAM
    }

    /** Contadores de um jogador. Ausente no mapa = ERS disponível. */
    private static final class ErsState {
        int activeTicks;
        int cooldownTicks;
    }

    private final Map<UUID, ErsState> states = new HashMap<>();

    // ---------- Consultas ----------

    public boolean isActive(ServerPlayer player) {
        return getRemainingActiveTicks(player) > 0;
    }

    public boolean isOnCooldown(ServerPlayer player) {
        return getRemainingCooldownTicks(player) > 0;
    }

    public int getRemainingActiveTicks(ServerPlayer player) {
        ErsState state = states.get(player.getUUID());
        return state == null ? 0 : state.activeTicks;
    }

    public int getRemainingCooldownTicks(ServerPlayer player) {
        ErsState state = states.get(player.getUUID());
        return state == null ? 0 : state.cooldownTicks;
    }

    // ---------- Ativação ----------

    /** Verifica as regras de ativação, sem alterar nada. */
    public ActivationResult checkActivation(ServerPlayer player) {
        if (F1Server.getDrivenBoat(player) == null) {
            return ActivationResult.NOT_DRIVING_BOAT;
        }
        if (isActive(player)) {
            return ActivationResult.ALREADY_ACTIVE;
        }
        if (isOnCooldown(player)) {
            return ActivationResult.ON_COOLDOWN;
        }
        if (F1Server.SLIPSTREAM.isInSlipstream(player)) {
            return ActivationResult.IN_SLIPSTREAM;
        }
        return ActivationResult.OK;
    }

    public boolean canActivate(ServerPlayer player) {
        return checkActivation(player) == ActivationResult.OK;
    }

    /** Tenta ativar. Só muda o estado se todas as regras passarem. */
    public ActivationResult activate(ServerPlayer player) {
        ActivationResult result = checkActivation(player);
        if (result == ActivationResult.OK) {
            ErsState state = states.computeIfAbsent(player.getUUID(), id -> new ErsState());
            state.activeTicks = F1Constants.ERS_DURATION_TICKS;
            state.cooldownTicks = 0;
        }
        return result;
    }

    // ---------- Tick ----------

    /** Chamado uma vez por tick, para cada jogador online. */
    public void tick(ServerPlayer player) {
        ErsState state = states.get(player.getUUID());
        if (state == null) {
            return;
        }

        if (state.activeTicks > 0) {
            state.activeTicks--;
            if (state.activeTicks == 0) {
                // Fim do ERS: a recarga começa agora.
                state.cooldownTicks = F1Constants.ERS_COOLDOWN_TICKS;
            }
        } else if (state.cooldownTicks > 0) {
            state.cooldownTicks--;
        }

        // Sem nada pendente: remove a entrada para o mapa não crescer.
        if (state.activeTicks == 0 && state.cooldownTicks == 0) {
            states.remove(player.getUUID());
        }
    }

    /** Descarta todo o estado (servidor parando). */
    public void clear() {
        states.clear();
    }
}