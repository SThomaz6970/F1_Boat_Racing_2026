package com.f1boat.server;

import com.f1boat.network.F1Networking;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.vehicle.boat.AbstractBoat;

/**
 * Ponto de entrada do lado servidor: registra os eventos e guarda os gerenciadores.
 * Código de servidor: nunca importe classes de cliente aqui.
 */
public final class F1Server {

    public static final BoatSpeedManager BOAT_SPEED = new BoatSpeedManager();
    public static final SlipstreamManager SLIPSTREAM = new SlipstreamManager();
    public static final ErsManager ERS = new ErsManager();

    /** Reenvia o estado a cada 1 segundo mesmo sem mudança (mantém o cliente em dia). */
    private static final int KEEPALIVE_TICKS = 20;

    /** Parte "grossa" do estado: só ela dispara um envio imediato quando muda. */
    private record SyncKey(boolean ersActive, boolean ersCooldown, boolean slipstream, double bonusBps) {
    }

    private static final Map<UUID, SyncKey> LAST_SYNC = new HashMap<>();

    private F1Server() {
    }

    /** Chamado por F1BoatMod.onInitialize. */
    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(F1Server::onServerTick);
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            BOAT_SPEED.clear();
            SLIPSTREAM.clear();
            ERS.clear();
            LAST_SYNC.clear();
        });
    }

    private static void onServerTick(MinecraftServer server) {
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            // A ordem importa: mede a velocidade -> avalia o vácuo -> avança o ERS -> sincroniza.
            BOAT_SPEED.tick(player);
            SLIPSTREAM.tick(player);
            ERS.tick(player);

            syncState(player);
        }
    }

    /**
     * Barco que o jogador está DIRIGINDO, ou null.
     * Passageiro (que não controla o barco) não conta. Inclui barco com baú e balsa.
     */
    public static AbstractBoat getDrivenBoat(ServerPlayer player) {
        if (player.getVehicle() instanceof AbstractBoat boat && boat.getControllingPassenger() == player) {
            return boat;
        }
        return null;
    }

    /**
     * Envia ao cliente o que o servidor decidiu (bônus, vácuo, tempos do ERS).
     * Só para quem está dirigindo; ao sair do barco manda um último estado "sem bônus".
     */
    private static void syncState(ServerPlayer player) {
        UUID id = player.getUUID();
        SyncKey last = LAST_SYNC.get(id);

        if (getDrivenBoat(player) == null) {
            if (last != null) {
                F1Networking.sendState(player, snapshot(player, false, 0.0));
                LAST_SYNC.remove(id);
            }
            return;
        }

        boolean slipstream = SLIPSTREAM.isInSlipstream(player);
        double bonus = BOAT_SPEED.getActiveBonusBps(player);
        SyncKey key = new SyncKey(ERS.isActive(player), ERS.isOnCooldown(player), slipstream, bonus);

        if (!key.equals(last) || player.tickCount % KEEPALIVE_TICKS == 0) {
            F1Networking.sendState(player, snapshot(player, slipstream, bonus));
            LAST_SYNC.put(id, key);
        }
    }

    private static F1Networking.StatePayload snapshot(ServerPlayer player, boolean slipstream, double bonusBps) {
        return new F1Networking.StatePayload(
                ERS.getRemainingActiveTicks(player),
                ERS.getRemainingCooldownTicks(player),
                slipstream,
                bonusBps
        );
    }
}