package com.f1boat.util;

/**
 * Constantes do mod. Nenhum valor de gameplay deve ser enviado pelo cliente:
 * o servidor é a única autoridade sobre estes números.
 */
public final class F1Constants {

    public static final String MOD_ID = "f1boat";
    public static final String MOD_NAME = "F1 Boat Racing";

    /** Minecraft roda a 20 ticks por segundo. */
    public static final int TICKS_PER_SECOND = 20;

    /** ERS ativo por 10 segundos. */
    public static final int ERS_DURATION_TICKS = 200;

    /** Recarga de 15 segundos, contada a partir do fim do ERS. */
    public static final int ERS_COOLDOWN_TICKS = 300;

    /** Distância máxima (em blocos) para receber vácuo. */
    public static final double SLIPSTREAM_RANGE = 10.0;

    /** Bônus do vácuo, em blocos por segundo, somado à velocidade normal. */
    public static final double SLIPSTREAM_BONUS_BPS = 2.0;

    /** Bônus do ERS, em blocos por segundo, somado à velocidade normal. */
    public static final double ERS_BONUS_BPS = 2.5;

    // ---------- Fase 5: ajuste fino do vácuo ----------

    /** Deslocamento lateral máximo (blocos) do alvo em relação ao eixo do seu barco. */
    public static final double SLIPSTREAM_MAX_LATERAL_OFFSET = 1.25;

    /** Distância mínima à frente (blocos) para o alvo contar como "à frente". */
    public static final double SLIPSTREAM_MIN_FORWARD_DISTANCE = 0.5;

    /**
     * Quão parecida deve ser a direção dos dois barcos (produto escalar dos vetores
     * "para frente": 1.0 = idênticos, 0.9 = cerca de 25 graus de diferença).
     */
    public static final double SLIPSTREAM_MIN_DIRECTION_DOT = 0.9;

    /** Tolerância (blocos/s) para considerar o barco na velocidade máxima normal. */
    public static final double MAX_SPEED_TOLERANCE_BPS = 0.5;

    private F1Constants() {
    }
}