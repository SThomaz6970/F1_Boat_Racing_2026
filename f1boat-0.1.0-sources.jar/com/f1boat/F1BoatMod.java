package com.f1boat;

import com.f1boat.network.F1Networking;
import com.f1boat.server.F1Server;
import com.f1boat.util.F1Constants;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Entrypoint comum (servidor + cliente, incluindo o servidor interno do singleplayer).
 * Aqui só ficam registros comuns; as regras de gameplay vivem em com.f1boat.com.f1boat.server.
 */
public class F1BoatMod implements ModInitializer {

    public static final Logger LOGGER = LoggerFactory.getLogger(F1Constants.MOD_ID);

    @Override
    public void onInitialize() {
        F1Networking.register();
        F1Server.register();

        LOGGER.info("{} inicializado.", F1Constants.MOD_NAME);
    }
}