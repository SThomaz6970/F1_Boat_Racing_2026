package com.f1boat.client;

import com.f1boat.F1BoatMod;
import net.fabricmc.api.ClientModInitializer;

/**
 * Entrypoint exclusivo do cliente: keybind, estado recebido do servidor e HUD.
 */
public class F1BoatClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        F1Keybinds.register();
        F1ClientState.register();
        F1Hud.register();

        F1BoatMod.LOGGER.info("F1 Boat Racing (cliente) inicializado.");
    }
}