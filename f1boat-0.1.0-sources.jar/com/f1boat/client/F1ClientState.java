package com.f1boat.client;

import com.f1boat.network.F1Networking;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

/**
 * Último estado enviado pelo servidor (somente leitura para o resto do cliente).
 * O cliente NÃO decide nada aqui: só guarda o que o servidor mandou.
 * Usado pelo Mixin (bônus) e pelo HUD.
 */
public final class F1ClientState {

    /** Sem atualização por tanto tempo (ticks) = estado considerado velho. */
    private static final int STALE_AFTER_TICKS = 60;

    private static int ersActiveTicks;
    private static int ersCooldownTicks;
    private static boolean inSlipstream;
    private static double bonusBps;
    private static int ageTicks = STALE_AFTER_TICKS;

    private F1ClientState() {
    }

    /** Chamado por F1BoatClient. */
    public static void register() {
        ClientPlayNetworking.registerGlobalReceiver(
                F1Networking.StatePayload.TYPE,
                (payload, context) -> update(payload)
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (ageTicks < STALE_AFTER_TICKS) {
                ageTicks++;
            }

            // Só para o número do HUD descer suavemente entre as atualizações do servidor.
            // Para em 1: quem encerra o ERS / a recarga é o servidor (o próximo pacote corrige).
            if (ersActiveTicks > 1) {
                ersActiveTicks--;
            }
            if (ersCooldownTicks > 1) {
                ersCooldownTicks--;
            }
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> reset());
    }

    private static void update(F1Networking.StatePayload payload) {
        ersActiveTicks = payload.ersActiveTicks();
        ersCooldownTicks = payload.ersCooldownTicks();
        inSlipstream = payload.inSlipstream();
        bonusBps = payload.bonusBps();
        ageTicks = 0;
    }

    private static void reset() {
        ersActiveTicks = 0;
        ersCooldownTicks = 0;
        inSlipstream = false;
        bonusBps = 0.0;
        ageTicks = STALE_AFTER_TICKS;
    }

    /** Estado velho (servidor parou de enviar). */
    public static boolean isStale() {
        return ageTicks >= STALE_AFTER_TICKS;
    }

    /** Bônus (blocos/s) que o servidor mandou aplicar; 0 se o estado estiver velho. */
    public static double getBonusBps() {
        return isStale() ? 0.0 : bonusBps;
    }

    public static int getErsActiveTicks() {
        return ersActiveTicks;
    }

    public static int getErsCooldownTicks() {
        return ersCooldownTicks;
    }

    public static boolean isInSlipstream() {
        return inSlipstream;
    }
}