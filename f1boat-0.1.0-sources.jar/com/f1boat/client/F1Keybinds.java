package com.f1boat.client;

import com.f1boat.network.F1Networking;
import com.f1boat.util.F1Constants;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

/**
 * Keybinds do mod. Existe SOMENTE no cliente: nunca referencie esta classe
 * a partir de código comum ou de servidor.
 *
 * A keybind aparece em Opções > Controles > Teclas, na categoria "F1 Boat Racing",
 * e o jogador pode remapeá-la normalmente.
 */
public final class F1Keybinds {

    /** Categoria: tradução em "key.category.f1boat.main". */
    private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(
            Identifier.fromNamespaceAndPath(F1Constants.MOD_ID, "main")
    );

    /**
     * Tecla "Ativar ERS": tradução em "key.f1boat.ers". Padrão: R.
     * No 26.3 o tipo de teclado é KEYBOARD (antes KEYSYM) e os códigos vêm de InputConstants (SDL).
     */
    private static final KeyMapping ERS_KEY = KeyMappingHelper.registerKeyMapping(
            new KeyMapping(
                    "key.f1boat.ers",
                    InputConstants.Type.KEYBOARD,
                    InputConstants.KEY_R,
                    CATEGORY
            )
    );

    private F1Keybinds() {
    }

    /**
     * Chamado por F1BoatClient. Ao carregar esta classe, a categoria e a tecla
     * já são registradas (campos estáticos acima); aqui registramos o tick.
     */
    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(F1Keybinds::onClientTick);
    }

    private static void onClientTick(Minecraft client) {
        // consumeClick() devolve true uma vez por pressão (várias, se apertou várias vezes no tick).
        while (ERS_KEY.consumeClick()) {
            if (client.player == null) {
                return;
            }

            // O cliente só PEDE. Quem decide se o ERS ativa é o servidor.
            ClientPlayNetworking.send(F1Networking.ActivateErsPayload.INSTANCE);
        }
    }
}