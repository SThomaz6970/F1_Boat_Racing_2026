package com.f1boat.client;

import com.f1boat.util.F1Constants;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.vehicle.boat.AbstractBoat;

/**
 * HUD do mod: um painel compacto com o estado do ERS e do vácuo.
 * Só aparece para o motorista de um barco. Só LÊ o estado enviado pelo servidor (F1ClientState).
 *
 * Para mudar posição, cores ou tamanho, edite as constantes abaixo.
 * Textos: assets/f1boat/lang/*.json (chaves "hud.f1boat.*").
 */
public final class F1Hud {

    /** Distância da borda esquerda da tela (pixels da GUI). */
    private static final int PANEL_X = 8;
    private static final int PADDING = 5;
    private static final int LINE_HEIGHT = 10;

    // Cores em ARGB (o primeiro FF é a opacidade; sem ele o texto fica transparente).
    private static final int BACKGROUND = 0x90000000;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int GREEN = 0xFF55FF55;
    private static final int ORANGE = 0xFFFFAA00;
    private static final int RED = 0xFFFF5555;
    private static final int AQUA = 0xFF55FFFF;

    private record Line(Component text, int color) {
    }

    private F1Hud() {
    }

    /** Chamado por F1BoatClient. */
    public static void register() {
        HudElementRegistry.addLast(
                Identifier.fromNamespaceAndPath(F1Constants.MOD_ID, "ers_panel"),
                (graphics, tickCounter) -> {
                    Minecraft minecraft = Minecraft.getInstance();
                    if (!shouldShow(minecraft)) {
                        return;
                    }

                    List<Line> lines = buildLines();

                    int textWidth = 0;
                    for (Line line : lines) {
                        textWidth = Math.max(textWidth, minecraft.font.width(line.text()));
                    }

                    int width = textWidth + PADDING * 2;
                    int height = lines.size() * LINE_HEIGHT + PADDING * 2 - 2;
                    int y = (minecraft.getWindow().getGuiScaledHeight() - height) / 2;

                    graphics.fill(PANEL_X, y, PANEL_X + width, y + height, BACKGROUND);

                    int textY = y + PADDING;
                    for (Line line : lines) {
                        graphics.text(minecraft.font, line.text(), PANEL_X + PADDING, textY, line.color(), true);
                        textY += LINE_HEIGHT;
                    }
                }
        );
    }

    /** Só para o motorista de um barco, e só com estado recente vindo do servidor. */
    private static boolean shouldShow(Minecraft minecraft) {
        var player = minecraft.player;
        if (player == null || F1ClientState.isStale()) {
            return false;
        }
        return player.getVehicle() instanceof AbstractBoat boat && boat.getControllingPassenger() == player;
    }

    private static List<Line> buildLines() {
        List<Line> lines = new ArrayList<>();

        lines.add(new Line(Component.translatable("hud.f1boat.ers"), WHITE));

        int activeTicks = F1ClientState.getErsActiveTicks();
        int cooldownTicks = F1ClientState.getErsCooldownTicks();

        if (activeTicks > 0) {
            lines.add(new Line(Component.translatable("hud.f1boat.active", seconds(activeTicks)), ORANGE));
        } else if (cooldownTicks > 0) {
            lines.add(new Line(Component.translatable("hud.f1boat.cooldown", seconds(cooldownTicks)), RED));
        } else {
            lines.add(new Line(Component.translatable("hud.f1boat.ready"), GREEN));
        }

        if (F1ClientState.isInSlipstream()) {
            lines.add(new Line(Component.empty(), WHITE));
            lines.add(new Line(Component.translatable("hud.f1boat.slipstream"), WHITE));
            lines.add(new Line(
                    Component.translatable("hud.f1boat.slipstream_bonus", oneDecimal(F1ClientState.getBonusBps())),
                    AQUA
            ));
        }

        return lines;
    }

    private static String seconds(int ticks) {
        return oneDecimal(ticks / (double) F1Constants.TICKS_PER_SECOND);
    }

    private static String oneDecimal(double value) {
        return String.format(Locale.ROOT, "%.1f", value);
    }
}